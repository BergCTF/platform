#!/usr/local/bin/python

from RestrictedPython import compile_restricted
from RestrictedPython import safe_globals
from ctypes import c_ulong

def safe_import(name, *args, **kwargs):
    if name not in frozenset():
        raise Exception(f"Nope, you can't import {name}!")
    return __import__(name, *args, **kwargs)

GLOBALS = {
    "__builtins__": {
        **safe_globals,
        "__import__": safe_import,
        "id": id,
        "int": int,
        "from_address": c_ulong.from_address,
        "setattr": setattr,
        "getattr": getattr,
    },
}

FLAG_CONSTANT = 42

while True:
    source_code = input(">>> ")
    byte_code = compile_restricted(source_code, '<inline>', 'exec')
    print(exec(byte_code, GLOBALS))
    if input("Exit (y/n)?: ").lower() == "y":
        break


if FLAG_CONSTANT == 42 and hash(FLAG_CONSTANT) == 1337:
    print("Congrats, here's your flag: shc2023{https://bit.ly/3CSyf5P}")
else:
    print("No flag for you!")
