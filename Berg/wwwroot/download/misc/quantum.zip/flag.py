#!/usr/bin/env python3

import hashlib

from Crypto.Util.Padding import pad, unpad
from Cryptodome.Cipher import AES

from backports.pbkdf2 import pbkdf2_hmac

SALT = b'LA_LI_LU_LE_LO_ARE_THE_PATRIOTS'

ENCRYPTED_FLAG = b'K\xd3W\xf9\x90\x121\xb5\xd2\x88\xc45y1\x8f\xe9\xd6\x7f!\xb1\xfa\xaa\x89J\xf5u8\xb4_\x1f@\x1b\xb5\xec\xaea\x13\xdc\xf2\xf7\x8eH\x07\x9c\xa4\xc1]\xf2'

# circuit passwords
circ1_pw = b''
circ2_pw = b''
circ3_pw = b''

print('[...] This will take a moment...')

# circuit 1
circ1_key = pbkdf2_hmac("sha256", circ1_pw, SALT, 5000000, 32)
assert circ1_key == b"`6~QAS\x8c;\x9c\x7f\xaa\xdc\xf9ood\xb1ASs2I.\xb1\x17\xb0<\x8f'>\x10\x80"
print('[+] Circuit 1 Password is correct! ')


# circuit 2
circ2_key = pbkdf2_hmac("sha256", circ2_pw, SALT, 5000000, 32)
assert circ2_key == b'\xe4.\xfb\xfd\xc2f\xd0\xe3\xd4\xb4\x86Z\xad\x95%\x8fX\x11\xe9\x07\xf6\xb9*\x087\x11\xd3\x95\x03\x12}\x8f'
print('[+] Circuit 2 Password is correct! ')


# circuit 3
circ3_key = pbkdf2_hmac("sha256", circ3_pw, SALT, 1337, 32)
print(circ3_key)
assert circ3_key == b'\xa7[\x90\x9d\xfae\xc5\x03?\xa6\x95\\\x1b\\\x03Pc\xf7\xfe\xf6\xb5\xad\xf8f\x10\x7f\x86\xc8\xe1\xa6O\xf6'
print('[+] Circuit 3 Password is correct! ')

# decrypt flag
AES_KEY = hashlib.md5(circ1_pw + circ2_pw + circ3_pw).hexdigest().encode('ascii')
aes_decrypter = AES.new(AES_KEY, AES.MODE_ECB)
print('[+] Flag: ' + unpad(aes_decrypter.decrypt(ENCRYPTED_FLAG),16).decode('ascii'))
