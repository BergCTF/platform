using dotcom.Db;
using dotcom.Middleware;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllers();
builder.Services.AddTransient<SecurityHeaderMiddleware>();
builder.Services.AddSingleton<ContentDb>();

var app = builder.Build();

app.UseMiddleware<SecurityHeaderMiddleware>();
app.UseStaticFiles();
app.MapControllers();

app.MapFallback(async ctx =>
{
    ctx.Response.ContentType = "text/html";
    await ctx.Response.WriteAsync($@"
<!doctype html>
<html lang=""en"">
<head>
    <meta charset=""utf-8"">
    <meta name=""viewport"" content=""width=device-width, initial-scale=1"">
    <title>dotcom</title>
    <link href=""https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css""
        nonce=""{ctx.Items["csp-nonce"]}"" rel=""stylesheet"" crossorigin=""anonymous""
        integrity=""sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD"">
</head>
<body>
    <noscript>This page JavaScripts. Please make sure you have it enabled!</noscript>
    <div class=""container"">
        <spa-content csp=""{ctx.Items["csp-nonce"]}""></spa-content>
    </div>
    <script src=""https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js""
        nonce=""{ctx.Items["csp-nonce"]}"" crossorigin=""anonymous""
        integrity=""sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN""></script>
    <script src=""/spa.js"" nonce=""{ctx.Items["csp-nonce"]}""></script>
</body>
</html>
");
});

app.Run();
