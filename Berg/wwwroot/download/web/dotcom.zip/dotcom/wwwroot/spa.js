﻿class SpaApplication {
    constructor() {
        let contentElements = document.getElementsByTagName("spa-content");
        if (contentElements.length !== 1) {
            console.error("No single spa-content element found!");
            return;
        }
        this.contentElement = contentElements[0];
        this.cspNonce = this.contentElement.getAttribute("csp");
        this.pages = {};
        let app = this;
        window.onpopstate = (event) => {
            let url = new URL(document.location);
            app.show(url.pathname);
        };
    }
    
    show(path) {
        console.log("Showing page: " + path);
        if(path in this.pages) {
            this.contentElement.innerHTML = this.pages[path].content;
            let links = [...this.contentElement.querySelectorAll("a[href]")];
            let app = this;
            links.forEach(l => l.addEventListener("click", function (event) {
                event.preventDefault();
                let url = new URL(event.target.href);
                app.show(url.pathname);
            }));
            let components = [...this.contentElement.querySelectorAll("spa-component")];
            components.forEach(c => new SpaComponent(c, this.cspNonce));
        } else {
            this.contentElement.innerHTML = "<b>Page not found.</b>";
        }
    }
    
    registerPage(page) {
        this.pages[page.path] = page;
    }
}

class SpaComponent {
    constructor(elem, nonce) {
        if (elem.dataset["initialized"] !== undefined)
            return;
        elem.dataset["initialized"] = "true";
        let name = elem.getAttribute("name");
        let value = elem.getAttribute("value");
        if (name === "copyright-year") {
            elem.innerHTML = "&copy;&nbsp;" + new Date().getFullYear() + "&nbsp;" + value;
            let components = [...document.querySelectorAll("spa-component")];
            components.forEach(c => new SpaComponent(c, nonce));
        } else if (name === "extension") {
            let extension = document.createElement("script");
            let url = new URL(value, location);
            if (url.hostname !== location.hostname) {
                console.log("Invalid extension hostname, not loading!")
                return;
            }
            extension.src = value;
            extension.nonce = nonce;
            document.body.appendChild(extension);
        } else if (name === "debug-log") {
            console.debug(value);
        } else if (name === "view-paste") {
            let pasteId = new URL(location).searchParams.get("id")
            fetch("/content/" + pasteId).then(r => {
                r.text().then(txt => {
                    elem.innerHTML = txt;
                    let components = [...document.querySelectorAll("spa-component")];
                    components.forEach(c => new SpaComponent(c, nonce));
                })
            });
        }
    }
}

class SpaPage {
    constructor(path, content) {
        this.path = path
        this.content = content
    }
}

let app = new SpaApplication();

let indexPage = new SpaPage("/", `
<div class="row">
    <h1>Dotcom</h1>
    <div class="alert alert-secondary" role="alert">
        Now with a modern, simple SPA framework that is intuitive and easy to use!
    </div>
</div>
<div class="row mt-5">
    <h3>Services</h3>
    <p>We here at dotcom do our best to provide you the following services:</p>
</div>
<div class="row mt-5">
    <div class="col-md-3 col-12">
        <h4>Pastebin <span class="badge bg-primary">New</span></h4>
        <p>Share your content with us and the world!</p>
        <a id="create" href="/create" class='btn btn-primary'>Create your first paste!</a>
    </div>
    <div class="col-md-3 col-12">
        <h4>Internet Explorer Engineering <span class="badge bg-secondary">Old</span></h4>
        <p>Currently out of stock.</p>
    </div>
    <div class="col-md-3 col-12">
        <h4>Support <span class="badge bg-primary">New</span></h4>
        <p>Talk to an admin that will help you out!</p>
        <a href="/support" class='btn btn-primary'>Talk to the admin!</a>
    </div>
    <div class="col-md-3 col-12">
        <h4>ActiveX Scripting <span class="badge bg-secondary">Old</span></h4>
        <p>Currently out of stock.</p>
    </div>
</div>
<div class="row mt-5">
    <spa-component name="copyright-year" value="dotcom"></spa-component>
</div>
`);
let createPage = new SpaPage("/create", `
<div class="row">
    <h1>Dotcom</h1>
    <a id="back" href="/" class="btn btn-secondary">Go Back</a>
</div>
<div class="row mt-5">
    <h3>Create a paste!</h3>
    <p>Please enter your content below:</p>
    <form id="createContent" action="/content" method="post">
        <div class="mb-3">
            <label for="textArea" class="form-label">Content</label>
            <textarea class="form-control" name="text" id="textArea" rows="3"></textarea>
        </div>
        <button id="submit" type="submit" class="btn btn-primary">Create</button>
    </form>
</div>
<div class="row mt-5">
    <spa-component name="copyright-year" value="dotcom"></spa-component>
</div>
`);
let contentPage = new SpaPage("/view", `
<div class="row">
    <h1>Dotcom</h1>
    <a id="back" href="/" class="btn btn-secondary">Go Back</a>
</div>
<div class="row mt-5">
    <h3>Viewing a paste:</h3>
    <spa-component name="view-paste"></spa-component>
</div>
<div class="row mt-5">
    <spa-component name="copyright-year" value="dotcom"></spa-component>
</div>
`);
let supportPage = new SpaPage("/support", `
<div class="row">
    <h1>Dotcom</h1>
    <a id="back" href="/" class="btn btn-secondary">Go Back</a>
</div>
<div class="row mt-5">
    <h3>Support!</h3>
    <p>Please create a content paste with your message and submit the id here:</p>
    <form id="reportContent" action="/report" method="post">
        <div class="mb-3">
            <label for="textArea" class="form-label">Content id to submit</label>
            <input class="form-control" name="id" />
        </div>
        <button id="submit" type="submit" class="btn btn-primary">Submit</button>
    </form>
</div>
<div class="row mt-5">
    <spa-component name="copyright-year" value="dotcom"></spa-component>
</div>
`);

app.registerPage(indexPage);
app.registerPage(createPage);
app.registerPage(contentPage);
app.registerPage(supportPage);

app.show(location.pathname);