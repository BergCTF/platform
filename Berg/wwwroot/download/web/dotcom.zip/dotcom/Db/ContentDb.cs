﻿namespace dotcom.Db;

public class ContentDb
{
    private readonly Dictionary<Guid, string> _contents = new();
    private readonly object _contentLock = new();

    public Guid AddContent(string text)
    {
        var id = Guid.NewGuid();
        lock (_contentLock)
        {
            while(_contents.ContainsKey(id))
                id = Guid.NewGuid();
            _contents[id] = text;
        }
        return id;
    }

    public string GetContent(Guid id)
    {
        lock (_contentLock)
        {
            return _contents.TryGetValue(id, out var content) ? content : "";
        }
    }
}