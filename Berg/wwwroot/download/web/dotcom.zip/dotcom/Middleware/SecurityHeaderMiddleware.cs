﻿using Microsoft.Extensions.Primitives;

namespace dotcom.Middleware;

public class SecurityHeaderMiddleware : IMiddleware
{
    private readonly Random _random;

    public SecurityHeaderMiddleware()
    {
        _random = new Random();
    }

    public async Task InvokeAsync(HttpContext ctx, RequestDelegate next)
    {
        var nonce = new byte[8];
        _random.NextBytes(nonce);
        ctx.Items["csp-nonce"] = Convert.ToHexString(nonce);
        ctx.Response.Headers.ContentSecurityPolicy = new StringValues(new []
        {
            $"script-src 'nonce-{ctx.Items["csp-nonce"]}'; base-uri 'none'; object-src 'none'"
        });
        ctx.Response.Headers["X-Content-Type-Options"] = "nosniff";
        await next(ctx);
    }
}