﻿using dotcom.Db;
using Microsoft.AspNetCore.Mvc;

namespace dotcom.Controllers;

[ApiController]
[Route("/content")]
public class ContentController : ControllerBase
{
    private readonly ContentDb _db;

    public ContentController(ContentDb db)
    {
        _db = db;
    }
    
    [HttpGet("{id:guid}", Name = "Get Content")]
    public IActionResult Get(Guid id)
    {
        return new ContentResult
        {
            ContentType = "text/html",
            Content = _db.GetContent(id)
        };
    }
    
    [HttpGet("share", Name = "Share Content")]
    public IActionResult Share(Uri link)
    {
        return Redirect(link.ToString());
    }

    [HttpPost(Name = "Post Content")]
    public IActionResult Post([FromForm] string text)
    {
        var id = _db.AddContent(text).ToString();
        return new RedirectResult($"/view?id={id}");
    }
}