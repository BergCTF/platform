﻿using Microsoft.AspNetCore.Mvc;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;

namespace dotcom.Controllers;

[ApiController]
[Route("/report")]
public class AdminController : ControllerBase
{
    private readonly ILogger<AdminController> _logger;

    public AdminController(ILogger<AdminController> logger)
    {
        _logger = logger;
    }
    
    [HttpPost(Name = "Checkout paste")]
    public IActionResult CheckoutPaste([FromForm] Guid id)
    {
        var pasteUrl = new UriBuilder
        {
            Host = "localhost",
            Port = 5000,
            Scheme = "http",
            Path = "/view",
            Query = $"id={id}",
        }.Uri;

        try
        {
            var options = new ChromeOptions();
            options.AddArgument("--headless");
            options.AddArgument("--no-sandbox");
            var driver = new ChromeDriver(options);

            // Load paste url to review content
            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromMilliseconds(500);
            driver.Navigate().GoToUrl(pasteUrl.ToString());
            
            Thread.Sleep(TimeSpan.FromSeconds(1));
            _logger.LogInformation("Admin visiting: {}", driver.Url);

            // Go back to main page
            var backButton = driver.FindElement(By.Id("back")) ??
                             throw new ArgumentException("No go back button found");
            backButton.Click();
            Thread.Sleep(TimeSpan.FromSeconds(1));
            _logger.LogInformation("Admin visiting: {}", driver.Url);
            if(new Uri(driver.Url).Host != "localhost")
                throw new ArgumentException("This is a single page application, no need to leave the page!");
        
            // Now on main page
            var pasteButton = driver.FindElement(By.Id("create")) ??
                              throw new ArgumentException("No create paste button found");
            pasteButton.Click();
            Thread.Sleep(TimeSpan.FromSeconds(1));
            _logger.LogInformation("Admin visiting: {}", driver.Url);
            if(new Uri(driver.Url).Host != "localhost")
                throw new ArgumentException("This is a single page application, no need to leave the page!");
            
            // Now on paste page, create a new paste
            var text = driver.FindElement(By.Id("textArea")) ??
                       throw new ArgumentException("Textarea not found");
            var submit = driver.FindElement(By.Id("submit")) ??
                         throw new ArgumentException("Submit button not found");
            if(new Uri(driver.Url).Host != "localhost")
                throw new ArgumentException("This is a single page application, no need to leave the page!");
            text.Click();
            text.SendKeys(Environment.GetEnvironmentVariable("FLAG"));
            submit.Click();
            _logger.LogInformation("Admin created his response");
            
            // Admin forgot the send you back the guid of his response...
            Thread.Sleep(TimeSpan.FromSeconds(3));
            driver.Quit();
        }
        catch (Exception ex)
        {
            _logger.LogError("Error running selenium: {}", ex);
            return new ContentResult
            {
                Content = "Something went wrong...",
                ContentType = "text/plain",
                StatusCode = 500
            };
        }
        
        return new ContentResult
        {
            Content = "I stored the information you wanted. Let me get a coffee before I send you the guid...",
            ContentType = "text/plain"
        };
    }
}