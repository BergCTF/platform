#!/usr/bin/env python3

from secret import FLAG
from Crypto.Cipher import AES
from secrets import randbelow
from hashlib import sha256


g = 2
p = 0xFFFFFFFFFFFFFFFFC90FDAA22168C234C4C6628B80DC1CD129024E088A67CC74020BBEA63B139B22514A08798E3404DDEF9519B3CD3A431B302B0A6DF25F14374FE1356D6D51C245E485B576625E7EC6F44C42E9A637ED6B0BFF5CB6F406B7EDEE386BFB5A899FA5AE9F24117C4B1FE649286651ECE45B3DC2007CB8A163BF0598DA48361C55D39A69163FA8FD24CF5F83655D23DCA3AD961C62F356208552BB9ED529077096966D670C354E4ABC9804F1746C08CA18217C32905E462E36CE3BE39E772C180E86039B2783A2EC07A28FB5C55DF06F4C52C9DE2BCBF6955817183995497CEA956AE515D2261898FA051015728E5A8AACAA68FFFFFFFFFFFFFFFF
q = 0X7FFFFFFFFFFFFFFFE487ED5110B4611A62633145C06E0E68948127044533E63A0105DF531D89CD9128A5043CC71A026EF7CA8CD9E69D218D98158536F92F8A1BA7F09AB6B6A8E122F242DABB312F3F637A262174D31BF6B585FFAE5B7A035BF6F71C35FDAD44CFD2D74F9208BE258FF324943328F6722D9EE1003E5C50B1DF82CC6D241B0E2AE9CD348B1FD47E9267AFC1B2AE91EE51D6CB0E3179AB1042A95DCF6A9483B84B4B36B3861AA7255E4C0278BA3604650C10BE19482F23171B671DF1CF3B960C074301CD93C1D17603D147DAE2AEF837A62964EF15E5FB4AAC0B8C1CCAA4BE754AB5728AE9130C4C7D02880AB9472D455655347FFFFFFFFFFFFFFF

class CuckooHashTable():
    def __init__(self, p, fn, n):
        self.p = p
        self.fn = fn
        self.k = [None] * p
        self.n = n
        self.table = [list() for _ in range(p)]

    def __len__(self):
        return len(self.table)

    def _h1(self, x):
        return x % self.p

    def _h2(self, x):
        return (x // self.p) % self.p

    def insert(self, x):
        x = int.from_bytes(x, "big")
        for h in [self._h1, self._h2]:
            i = h(x)
            fn_x = self.fn(x, self.get_k(i))
            self.table[i].append(fn_x)

    def get_k(self, idx):
        if not self.k[idx]:
            self.k[idx] = [randbelow(q) for _ in range(self.n + 1)]
        return self.k[idx]

    def __getitem__(self, i):
        return self.table[i]

def i2b(i):
    return i.to_bytes(256, "big")

def kdf(i):
    b = i2b(i)
    return sha256(b).digest()

def get_int(s):
    while True:
        try:
            return int(input(s))
        except ValueError:
            print("invalid input")

def ot_server(m0, m1):
    a = randbelow(q)
    A = pow(g, a, p)
    print(f"A = {A}")

    B = get_int("B = ")
    if B < 1 or B >= p or pow(B, q, p) != 1:
        exit(0)
    k0 = kdf(pow(B, a, p))
    k1 = kdf(pow((B * pow(A, -1, p)) % p, a, p))

    cipher0 = AES.new(k0, AES.MODE_CBC)
    e0 = (cipher0.iv + cipher0.encrypt(i2b(m0))).hex()
    cipher1 = AES.new(k1, AES.MODE_CBC)
    e1 = (cipher1.iv + cipher1.encrypt(i2b(m1))).hex()

    print(f"e0 = {e0}\ne1 = {e1}")

def nr_prf_server(n, table):
    idx = get_int("Bin idx = ")

    if 0 <= idx < len(table) and len(table[idx]) == 0:
        print("No match")
        return

    k = table.get_k(idx)
    r = [randbelow(q) for _ in range(n)]

    inv_r = 1
    for ri in r:
        inv_r = (inv_r * ri) % q
    inv_r = (k[0] * pow(inv_r, -1, q)) % q
    print("server inv_r", inv_r)

    g_hat = pow(g, inv_r, p)
    print(f"g_hat = {g_hat}")

    for i, ri in enumerate(r):
        ot_server(ri, (k[i+1] * ri) % q)

    print("I have the following elements:")
    print(table[idx])

def f_nr(x, k):
    l = x.bit_length()
    n = l + ((-l) % 8)
    exp = k[0]
    for i in range(n):
        xi = (x >> i) & 0b1
        exp = (exp * (k[i+1]**xi)) % q
    return pow(g, exp, p)

if __name__ == "__main__":
    s = 641317
    l = 12
    server_set = [b"1337deadbeef"] + [FLAG[i:i+l] for i in range(0, len(FLAG), l)]
    n = 8 * l

    table = CuckooHashTable(s, f_nr, n)
    for e in server_set:
        table.insert(e)
        assert len(e) <= l

    print("If you already know the flag, I'll tell you the flag.\n")
    while True:
        print("\n\nLet's start the OPRF.")
        nr_prf_server(n, table)
