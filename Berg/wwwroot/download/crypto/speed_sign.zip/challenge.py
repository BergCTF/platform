#!/usr/bin/env python3

from secret import FLAG
from secrets import token_bytes
from Crypto.Util.number import getPrime, isPrime
from Crypto.Signature.pss import MGF1
from Crypto.Hash import SHA256

NLEN = 256
TESTING = False

MENU = """\
               000000000
            0000       0000
         0000             0000
         00                 00
         00   Speed Sign!   00
         00                 00
         0000             0000
            0000       0000
               000000000
                   0
                   0
                   0
                   0
                   0
                   0
                   0
                   0

    Welcome to Speed Sign(C), the super
    fast signature library for resource
    constrained devices.Faster and less
    energy consumption: what more could
    your toaster possibly ever desire ?
"""

def xor(x, y):
    if len(x) > len(y):
        x, y = y, x
    return bytes([x[i] ^ y[i] for i in range(len(x))]) + y[len(x):]

class RSA:
    def __init__(self, keys=None):
        if not keys:
            self.sk, self.pk = self._key_gen()
        else:
            self.sk, self.pk = keys

    def _key_gen(self):
        n_e = NLEN * 4
        n_k = 400
        e = getPrime(n_e)

        def construct_prime():
            while True:
                ki = getPrime(n_k)
                di = pow(e, -1, ki)
                pi = 1 + (e * di - 1) // ki
                if isPrime(pi):
                    print("found!")
                    return pi, di

        p, dp = construct_prime()
        q, dq = construct_prime()
        n = p * q
        u = pow(q, -1, p)

        return (n, dp, dq, p, q, u), (n, e)

    def verify(self, m, sig):
        n, e = self.pk
        m_pad = int(pow(sig, e, n)).to_bytes(NLEN, "big")
        return self.unpad(m_pad) == SHA256.new(m).digest()

    def unpad(self, m_pad, k=NLEN, rlen=32): 
        x, y = m_pad[2:-rlen], m_pad[-rlen:]
        r = xor(y, MGF1(x, rlen, SHA256))
        m = xor(x, MGF1(r, k - rlen - 2, SHA256)).rstrip(b"\x00")
        return m[:-1]

    def pad(self, m, k=256, rlen=32):
        m += b"\x01" + b"\x00" * (k - rlen - 3 - len(m))
        r = token_bytes(rlen)
        x = xor(m, MGF1(r, k - rlen - 2, SHA256))
        y = xor(r, MGF1(x, rlen, SHA256))
        m_pad = x + y
        return m_pad
        
    def sign(self, m):
        m = self.pad(SHA256.new(m).digest())
        m = int.from_bytes(m, "big")
        n, dp, dq, p, q, u = self.sk
        sp = pow(m, dp, p)
        sq = pow(m, dq, q)
        t = sp - sq
        if t < 0:
            t += p
        return sq + ((t * u) % p) * q

    def sign_str(self, s):
        sig_int = self.sign(s.encode())
        return sig_int.to_bytes(NLEN, "big").hex()

if TESTING:
    rsa = RSA()
    n, e = rsa.pk
    for _ in range(100):
        m = token_bytes(20)
        assert rsa.verify(m, rsa.sign(m))
    print("Sanity check passed")

if __name__ == "__main__":
    rsa = RSA()

    print("Public key: ({}, {})\n\n".format(*tuple(map(hex, rsa.pk))))
    print(MENU)

    SHOWCASE = "Wow, so fast \\(O.O)/"
    print(f"Example: {SHOWCASE}")
    print(f"Sig: {rsa.sign_str(SHOWCASE)}\n\n")

    while True:
        m = input("Enter message: ").encode()
        try:
            sig = int(input("Enter signature: "), 16)
        except ValueError:
            print("Signature must be a hex value.")
            continue

        r = rsa.verify(m, sig)
        print(f"Verified: {r}")

        if r and m == b"Gimme the flag!":
            print(FLAG)
